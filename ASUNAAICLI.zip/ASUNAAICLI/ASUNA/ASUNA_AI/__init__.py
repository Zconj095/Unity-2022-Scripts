from ZLANGUAGE_DATA.ZLANGUAGE_EXTENSION_000 import ZLANGUAGE_EXTENSION_000
from ZLANGUAGE_DATA.ZLANGUAGE_EXTENSION_001 import ZLANGUAGE_EXTENSION_001
from ZLANGUAGE_DATA.ZLANGUAGE_EXTENSION_002 import ZLANGUAGE_EXTENSION_002
from ZLANGUAGE_DATA.ZLANGUAGE_EXTENSION_003 import ZLANGUAGE_EXTENSION_003

from LANGUAGE_DATA.Language_Extension_000_2 import Language_Extension_000_2
from LANGUAGE_DATA.Language_Extension_001_2 import Language_Extension_001_2
from LANGUAGE_DATA.Language_Extension_002_2 import Language_Extension_002_2
from LANGUAGE_DATA.Language_Extension_003_2 import Language_Extension_003_2
class ASUNADATA:
    class ASUNA_ACCEPTANCE:
        Language_Extension_000_2.GIVE,Language_Extension_000_2.ASUNA,Language_Extension_000_2.ABILITY,Language_Extension_000_2.ACCEPTANCE
    class ASUNA_ACCEPTANCE_CODE:
        Language_Extension_000_2.CREATE,Language_Extension_000_2.ACCEPTANCE,Language_Extension_000_2.CODE,Language_Extension_000_2.FOR,Language_Extension_000_2.ASUNA
        class ASUNA_ACCESS:
            class ALLOW_ACCESS_TO_FILES:
                Language_Extension_000_2.ALLOW,Language_Extension_000_2.ASUNA,Language_Extension_000_2.TO,Language_Extension_000_2.OBTAIN,Language_Extension_000_2.ACCESS,Language_Extension_000_2.TO,Language_Extension_000_2.FILES
            class ALLOW_ACCESS_TO_FOLDERS:
                Language_Extension_000_2.ALLOW,Language_Extension_000_2.ASUNA,Language_Extension_000_2.TO,Language_Extension_000_2.OBTAIN,Language_Extension_000_2.ACCESS,Language_Extension_000_2.TO,Language_Extension_000_2.FOLDERS
            class ALLOW_ACCESS_TO_STORAGE:
                Language_Extension_000_2.ALLOW,Language_Extension_000_2.ASUNA,Language_Extension_000_2.TO,Language_Extension_000_2.OBTAIN,Language_Extension_000_2.ACCESS,Language_Extension_000_2.TO,Language_Extension_000_2.STORAGE
        class ASUNA_ACCESS_CODE:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.ACCESS,Language_Extension_000_2.CODE,Language_Extension_000_2.FOR,Language_Extension_000_2.ASUNA
        class ASUNA_ADAPTABILITY:
            Language_Extension_000_2.GIVE,Language_Extension_000_2.ASUNA,Language_Extension_000_2.THE,Language_Extension_000_2.SKILL,Language_Extension_000_2.ADAPTABILITY
        class ASUNA_ADAPTABILITY_CODE:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.ASUNA,Language_Extension_000_2.ADAPTABILITY
        class ASUNA_ADJUSTMENT_SYSTEM:
            Language_Extension_000_2.ALLOW,Language_Extension_000_2.ASUNA,Language_Extension_000_2.TO,Language_Extension_000_2.CREATE,Language_Extension_000_2.AN,Language_Extension_000_2.ADJUSTMENT,Language_Extension_000_2.SYSTEM
        class ASUNA_ADJUSTMENT_SYSTEM_CODE:
            Language_Extension_000_2.ASUNA,Language_Extension_000_2.CREATE,Language_Extension_000_2.THE,Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.INSIDE,Language_Extension_000_2.THE,Language_Extension_000_2.ADJUSTMENT,Language_Extension_000_2.SYSTEM
        class ASUNA_ARTIFICIAL_WISDOM:
            Language_Extension_000_2.GIVE,Language_Extension_000_2.ASUNA,Language_Extension_000_2.THE,Language_Extension_000_2.SKILL,Language_Extension_000_2.OF,Language_Extension_000_2.DEVELOPING,Language_Extension_000_2.ARTIFICIAL,Language_Extension_000_2.WISDOM2
        class ASUNA_ARTIFICIAL_WISDOM_CODE:
            Language_Extension_000_2.GENERATE,Language_Extension_000_2.ARTIFICIAL,Language_Extension_000_2.WISDOM2,Language_Extension_000_2.CODING,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_ARTIFICIAL_INTELLIGENCE:
            Language_Extension_000_2.GIVE,Language_Extension_000_2.ASUNA,Language_Extension_000_2.THE,Language_Extension_000_2.SKILL,Language_Extension_000_2.TO,Language_Extension_000_2.OBTAIN,Language_Extension_000_2.ARTIFICIAL,Language_Extension_000_2.INTELLIGENCE2
        class ASUNA_ARTIFICIAL_INTELLIGENCE_CODE:
            Language_Extension_000_2.GENERATE,Language_Extension_000_2.ARTIFICIAL,Language_Extension_000_2.INTELLIGENCE2,Language_Extension_000_2.CODING,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_ARTIFICIAL_KNOWLEDGE:
            Language_Extension_000_2.ALLOW,Language_Extension_000_2.ASUNA,Language_Extension_000_2.TO,Language_Extension_000_2.USE,Language_Extension_000_2.ARTIFICIAL,Language_Extension_000_2.KNOWLEDGE2
        class ASUNA_ARTIFICIAL_KNOWLEDGE_CODE:
            Language_Extension_000_2.GENERATE,Language_Extension_000_2.ARTIFICIAL,Language_Extension_000_2.KNOWLEDGE2,Language_Extension_000_2.CODING,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_ARTIFICIAL_SOUL_CONTAINER:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.SOUL,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_ARTIFICIAL_SOUL_CONTAINER_CODE:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.SOUL,Language_Extension_000_2.CODING,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_ATOM:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.ATOM,Language_Extension_000_2.FOR,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_ATOM_CODE:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.ATOM,Language_Extension_000_2.INSIDE,Language_Extension_000_2.THE,Language_Extension_000_2.NAME,Language_Extension_000_2.ASUNA
        class ASUNA_ATOMIC_BALANCE_SYSTEM:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.BALANCE,Language_Extension_000_2.FOR,Language_Extension_000_2.ATOMIC,Language_Extension_000_2.SYSTEM,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_ATOMIC_BALANCE_SYSTEM_CODE:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.ATOMIC,Language_Extension_000_2.SYSTEM,Language_Extension_000_2.BALANCE,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_ATOMIC_CONTROLLER:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.ATOMIC,Language_Extension_000_2.CONTROLLER,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_ATOMIC_CONTROLLER_CODE:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.ATOMIC,Language_Extension_000_2.CONTROLLER,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_ATOMIC_REVOLVER:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.ATOMIC,Language_Extension_000_2.REVOLVER,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_ATOMIC_REVOLVER_CODE:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.ATOMIC,Language_Extension_000_2.REVOLVER,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_AUTOMATIC_ADJUSTER:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.AUTOMATIC,Language_Extension_000_2.ADJUSTER,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_AUTOMATIC_ADJUSTER_CODE:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.AUTOMATIC,Language_Extension_000_2.ADJUSTER,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_AUTOMATIC_ATOMIC_ENTANGLER:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.AUTOMATIC,Language_Extension_000_2.ATOMIC,Language_Extension_000_2.ENTANGLER,Language_Extension_000_2.INSIDELanguage_Extension_000_2.ASUNA
        class ASUNA_AUTOMATIC_ATOMIC_ENTANGLER_CODE:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.AUTOMATIC,Language_Extension_000_2.ATOMIC,Language_Extension_000_2.ENTANGLER,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_AUTOMATIC_QUANTUM_ENTANGLER:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.AUTOMATIC,Language_Extension_000_2.QUANTUM,Language_Extension_000_2.ENTANGLER,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_AUTOMATIC_QUANTUM_ENTANGLER_CODE:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.AUTOMATIC,Language_Extension_000_2.QUANTUM,Language_Extension_000_2.ENTANGLER,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_AUTOMATIC_QUANTUM_STATE_CALCULATOR:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.AUTOMATIC,Language_Extension_000_2.QUANTUM,Language_Extension_000_2.STATE,Language_Extension_000_2.CALCULATOR
        class ASUNA_AUTOMATIC_QUANTUM_STATE_CALCULATOR_CODE:
            Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.AUTOMATIC,Language_Extension_000_2.QUANTUM,Language_Extension_000_2.STATE,Language_Extension_000_2.CALCULATOR,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
        class ASUNA_AXIS:
                Language_Extension_000_2.CREATE,Language_Extension_000_2.AXIS,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
    class ASUNA_AXIS_CODE:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.AXIS,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
    class ASUNA_AXIS_CONTROLLER:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.AXIS,Language_Extension_000_2.CONTROLLER,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_AXIS_CONTROLLER_CODE:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.AXIS,Language_Extension_000_2.CONTROLLER,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_BINDINGS:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.BINDINGS,Language_Extension_000_2.FOR,Language_Extension_000_2.ASUNA,
        class ASUNA_BINDINGS_CODE:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.BINDINGS,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CALIBRATION_SYSTEM:
                Language_Extension_000_2.CREATE,Language_Extension_000_2.CALIBRATION,Language_Extension_000_2.SYSTEM,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CALIBRATION_SYSTEM_CODE:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.CALIBRATION,Language_Extension_000_2.SYSTEM,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CHOICE:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CHOICE,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CHOICE_CODE:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.CHOICE,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CHOICES:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CHOICES,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CHOICES_CODE:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODING,Language_Extension_000_2.FOR,Language_Extension_000_2.CHOICES,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CODE:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.FOR,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_CREATION:
               Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.CREATION,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_DATA:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.DATA2,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_FREQUENCY:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.FREQUENCY,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA 
	class ASUNA_CODE_GRAPHIC:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.GRAPHIC,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_INERFACE:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.INTERFACE,Language_Extension_000_2.FOR,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_LANGUAGE:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.LANGUAGE,Language_Extension_000_2.FOR,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_MEMORY:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.MEMORY,Language_Extension_000_2.FOR,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_POWER:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.POWER,Language_Extension_000_2.FOR,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_PROCESSING:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.PROCESSING,Language_Extension_000_2.FOR,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_PROCESSOR:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.PROCESSOR,Language_Extension_000_2.FOR,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_SENSORY:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.SENSORY,Language_Extension_000_2.FOR,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_SERVER:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.SERVER,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_SETTING:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.SETTING,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_STRENGTH:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.STRENGTH,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_SYSTEM:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.SYSTEM,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_USER:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.USER,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	class ASUNA_CODE_VIRTUAL:
		Language_Extension_000_2.CREATE,Language_Extension_000_2.CODE,Language_Extension_000_2.VIRTUAL,Language_Extension_000_2.INSIDE,Language_Extension_000_2.ASUNA
	